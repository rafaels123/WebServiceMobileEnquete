package com.mobileenquete.me.server.dao;

public interface Teste {
	
	
	public void eNumer();

}
