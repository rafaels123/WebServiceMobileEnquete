/**
 * 
 */
package com.mobileenquete.me.server.services.equipeServices;

/**
 * @author simao
 *
 */
public class EquipeServices {

}
